/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eserciziocontobancario;

import javax.swing.JOptionPane;

/**
 *
 * @author lorenzo.guglielmetto
 */
public class ContoEsteso extends ContoBancario{
    
    protected int fido;
    
    public ContoEsteso(String identificativo) {
        super(identificativo);
        this.fido = 1000;
    }
    
    public ContoEsteso (String identificativo, int bilancio){
        super(identificativo, bilancio);
        this.fido = 1000;
    }
    
    public ContoEsteso (String identificativo, int bilancio, int fido){
        super(identificativo, bilancio);
        this.fido = fido;
    }
    
    public int getFido (){
        return fido;
    }
    
    public void setFido (int fido){
        this.fido = fido;
    }
    
    @Override
    public void prelievo (int prelievo){
        if((bilancio+fido) < prelievo)
            System.out.println("Bilancio e fido insufficienti");
        else 
            bilancio -= prelievo;
    }
}


