/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eserciziocontobancario;

import javax.swing.JOptionPane;

/**
 *
 * @author lorenzo.guglielmetto
 */
public class ContoBancario {
    
    protected String identificativo;
    protected int bilancio;
    
    public ContoBancario (String identificativo) {
        this.identificativo = identificativo;
        this.bilancio = 0;
    }
    
    public ContoBancario (String identificativo, int bilancio) {
        this.identificativo = identificativo;
        this.bilancio = bilancio;
    }
    
    public String getIdentificativo (){
        return identificativo;
    }
    
    public int getBilancio (){
        return bilancio;
    }
    
    public void versamento (int versamento){
        bilancio += versamento;
    }
    
    public void prelievo (int prelievo){
        if(bilancio < prelievo)
            System.out.println("Bilancio insufficiente");
        else 
            bilancio -= prelievo;
    }
}
