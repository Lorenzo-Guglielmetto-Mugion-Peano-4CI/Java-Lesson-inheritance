/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eserciziocontobancario;

import javax.swing.JOptionPane;

/**
 *
 * @author lorenzo.guglielmetto
 */
public class EsercizioContoBancario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ContoBancario conto1 = new ContoBancario("a1gcf3y");
        ContoBancario conto2 = new ContoBancario("adkjh23", 1200);
        ContoEsteso conto3 = new ContoEsteso("hg234jhg5");
        ContoEsteso conto4 = new ContoEsteso("ajt3244", 9888);
        ContoEsteso conto5 = new ContoEsteso("25gu2uygh", 4665, 1200);
        System.out.println("identificativo conto1: "+conto1.getIdentificativo());
        System.out.println("identificativo conto2: "+conto2.getIdentificativo());
        System.out.println("identificativo conto3: "+conto3.getIdentificativo());
        System.out.println("identificativo conto4: "+conto4.getIdentificativo());
        System.out.println("identificativo conto5: "+conto5.getIdentificativo());
        conto1.versamento(Integer.parseInt(JOptionPane.showInputDialog("Inserire versamento")));
        conto2.versamento(Integer.parseInt(JOptionPane.showInputDialog("Inserire versamento")));
        conto3.versamento(Integer.parseInt(JOptionPane.showInputDialog("Inserire versamento")));
        conto4.versamento(Integer.parseInt(JOptionPane.showInputDialog("Inserire versamento")));
        conto5.versamento(Integer.parseInt(JOptionPane.showInputDialog("Inserire versamento")));
        System.out.println("bilancio conto1: "+conto1.getBilancio());
        System.out.println("bilancio conto2: "+conto2.getBilancio());
        System.out.println("bilancio conto3: "+conto3.getBilancio());
        System.out.println("bilancio conto4: "+conto4.getBilancio());
        System.out.println("bilancio conto5: "+conto5.getBilancio());
        conto1.prelievo(Integer.parseInt(JOptionPane.showInputDialog("Inserire prelievo")));
        conto2.prelievo(Integer.parseInt(JOptionPane.showInputDialog("Inserire prelievo")));
        conto3.prelievo(Integer.parseInt(JOptionPane.showInputDialog("Inserire prelievo")));
        conto4.prelievo(Integer.parseInt(JOptionPane.showInputDialog("Inserire prelievo")));
        conto5.prelievo(Integer.parseInt(JOptionPane.showInputDialog("Inserire prelievo")));
        System.out.println("bilancio conto1: "+conto1.getBilancio());
        System.out.println("bilancio conto2: "+conto2.getBilancio());
        System.out.println("bilancio conto3: "+conto3.getBilancio());
        System.out.println("bilancio conto4: "+conto4.getBilancio());
        System.out.println("bilancio conto5: "+conto5.getBilancio());
        System.out.println("fido conto3: "+conto3.getFido());
        System.out.println("fido conto4: "+conto4.getFido());
        System.out.println("fido conto5: "+conto5.getFido());
        conto3.setFido(Integer.parseInt(JOptionPane.showInputDialog("Inserire nuovo valore fido")));
        conto4.setFido(Integer.parseInt(JOptionPane.showInputDialog("Inserire nuovo valore fido")));
        conto5.setFido(Integer.parseInt(JOptionPane.showInputDialog("Inserire nuovo valore fido")));
        System.out.println("fido conto3: "+conto3.getFido());
        System.out.println("fido conto4: "+conto4.getFido());
        System.out.println("fido conto5: "+conto5.getFido());
    }
    
}
